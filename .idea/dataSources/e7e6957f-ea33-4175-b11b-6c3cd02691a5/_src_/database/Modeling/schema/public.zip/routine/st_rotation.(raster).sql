create function st_rotation(raster) returns double precision
LANGUAGE SQL
AS $$
SELECT ( public.ST_Geotransform($1)).theta_i
$$;
