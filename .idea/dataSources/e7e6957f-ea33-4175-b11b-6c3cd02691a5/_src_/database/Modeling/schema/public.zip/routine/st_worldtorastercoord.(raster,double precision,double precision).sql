create function st_worldtorastercoord(rast raster, longitude double precision, latitude double precision, OUT columnx integer, OUT rowy integer) returns record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT columnx, rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;
