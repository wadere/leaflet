create function st_rastertoworldcoordx(rast raster, xr integer) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, NULL)
$$;
