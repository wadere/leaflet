create function st_mlinefromtext(text, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE
	WHEN public.geometrytype(public.ST_GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN public.ST_GeomFromText($1,$2)
	ELSE NULL END

$$;
