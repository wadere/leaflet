create function st_length(text) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Length($1::public.geometry);
$$;
