create function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)
$$;
