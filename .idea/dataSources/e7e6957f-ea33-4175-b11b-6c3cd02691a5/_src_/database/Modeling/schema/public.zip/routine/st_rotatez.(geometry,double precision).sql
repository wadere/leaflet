create function st_rotatez(geometry, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Rotate($1, $2)
$$;
