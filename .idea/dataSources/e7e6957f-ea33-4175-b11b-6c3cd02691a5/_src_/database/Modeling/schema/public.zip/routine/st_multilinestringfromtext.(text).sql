create function st_multilinestringfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_MLineFromText($1)
$$;
