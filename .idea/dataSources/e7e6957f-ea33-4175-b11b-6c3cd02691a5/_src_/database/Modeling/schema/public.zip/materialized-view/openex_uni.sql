CREATE MATERIALIZED VIEW openex_uni AS SELECT DISTINCT (ROW(openex.lat, openex.lon))::character(30) AS latlon,
    openex.lat,
    openex.lon
   FROM openex;
