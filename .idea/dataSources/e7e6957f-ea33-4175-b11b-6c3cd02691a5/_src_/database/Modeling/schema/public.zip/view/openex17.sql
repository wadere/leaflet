CREATE VIEW openex17 AS SELECT a.date,
    date_part('year'::text, (a.date)::date) AS yr,
    date_part('month'::text, (a.date)::date) AS month,
    date_part('day'::text, (a.date)::date) AS day,
    avg(a.lon) AS lon,
    avg(a.lat) AS lat,
    a.model,
    a.scen,
    sum(
        CASE a.var
            WHEN 'pr'::text THEN round(a.val, 4)
            ELSE NULL::numeric
        END) AS prcp,
    max(
        CASE a.var
            WHEN 'tasmax'::text THEN (((round(a.val, 4) - '273'::numeric) * 1.8) + (32)::numeric)
            ELSE NULL::numeric
        END) AS tmax,
    min(
        CASE a.var
            WHEN 'tasmin'::text THEN (((round(a.val, 4) - '273'::numeric) * 1.8) + (32)::numeric)
            ELSE NULL::numeric
        END) AS tmin,
    st_setsrid(st_point(('-114.875'::numeric)::double precision, (42.125)::double precision), 4326) AS geom
   FROM openex a
  GROUP BY a.date, a.model, a.scen;
