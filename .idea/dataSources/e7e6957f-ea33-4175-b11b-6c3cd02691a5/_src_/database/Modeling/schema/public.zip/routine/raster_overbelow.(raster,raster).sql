create function raster_overbelow(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry &<| $2::geometry
$$;
