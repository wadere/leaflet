create function st_force_4d(geometry) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Force_4d', 'ST_Force4D', '2.1.0');
    SELECT public.ST_Force4D($1);
$$;
