create function st_buffer(geometry, double precision, text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_Buffer($1, $2,
		CAST( regexp_replace($3, '^[0123456789]+$',
			'quad_segs='||$3) AS cstring)
		)

$$;
