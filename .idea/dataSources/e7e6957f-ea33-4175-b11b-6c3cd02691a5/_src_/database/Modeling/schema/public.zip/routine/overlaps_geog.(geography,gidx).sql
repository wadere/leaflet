create function overlaps_geog(geography, gidx) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&) $1;
$$;
