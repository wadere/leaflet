create function st_approxcount(rastertable text, rastercolumn text, sample_percent double precision) returns bigint
STABLE
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, $2, 1, TRUE, $3)
$$;
