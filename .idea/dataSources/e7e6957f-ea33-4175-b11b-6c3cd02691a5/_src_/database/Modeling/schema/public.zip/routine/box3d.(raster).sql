create function box3d(raster) returns box3d
IMMUTABLE
LANGUAGE SQL
AS $$
select box3d( public.ST_convexhull($1))
$$;
