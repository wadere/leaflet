create function raster_overleft(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::public.geometry &< $2::public.geometry
$$;
