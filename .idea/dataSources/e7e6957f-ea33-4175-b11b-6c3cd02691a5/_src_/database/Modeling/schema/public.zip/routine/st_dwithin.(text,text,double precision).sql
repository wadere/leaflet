create function st_dwithin(text, text, double precision) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_DWithin($1::public.geometry, $2::public.geometry, $3);
$$;
