create function st_translate(geometry, double precision, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Translate($1, $2, $3, 0)
$$;
