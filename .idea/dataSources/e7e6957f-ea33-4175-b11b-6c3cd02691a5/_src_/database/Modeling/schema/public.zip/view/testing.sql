CREATE VIEW testing AS SELECT 'hello' AS hello,
    'world' AS world;
