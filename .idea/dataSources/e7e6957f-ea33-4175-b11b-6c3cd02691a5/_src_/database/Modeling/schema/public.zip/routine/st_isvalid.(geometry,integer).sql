create function st_isvalid(geometry, integer) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;
