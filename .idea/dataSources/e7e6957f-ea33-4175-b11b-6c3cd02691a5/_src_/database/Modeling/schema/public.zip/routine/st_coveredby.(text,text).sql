create function st_coveredby(text, text) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_CoveredBy($1::public.geometry, $2::public.geometry);
$$;
