create function postgis_raster_scripts_installed() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.3.2'::text || ' r' || 15302::text AS version
$$;
